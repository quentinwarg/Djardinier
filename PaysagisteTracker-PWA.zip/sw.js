// PaysagisteTracker — Service Worker
// Permet le fonctionnement 100% hors-ligne

const CACHE_NAME = 'paysagiste-v1';
const XLSX_URL = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';

// Fichiers à mettre en cache au démarrage
const PRECACHE = [
  './paysagiste.html',
  './manifest.json',
  XLSX_URL,
];

// Installation : mise en cache initiale
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(PRECACHE).catch(err => {
        // Si XLSX ne charge pas (pas de réseau), on continue quand même
        return cache.addAll(['./paysagiste.html', './manifest.json']);
      });
    }).then(() => self.skipWaiting())
  );
});

// Activation : nettoyage des anciens caches
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// Fetch : cache-first pour les ressources locales, network-first pour le reste
self.addEventListener('fetch', event => {
  const url = new URL(event.request.url);

  // Ressources locales → cache d'abord
  if (url.origin === location.origin || event.request.url.includes('cdnjs')) {
    event.respondWith(
      caches.match(event.request).then(cached => {
        if (cached) return cached;
        return fetch(event.request).then(response => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
          }
          return response;
        }).catch(() => cached || new Response('Hors ligne', { status: 503 }));
      })
    );
  }
});
